/*
ANKIT LALOTRA
19CS30004
Assignment-2
date:2/09/2021
*/

#include "myl.h"

// Function to print the string 
int printStr(char *s) 
{
    int char_count = 0;
    char temp[1000];
    for(;s[char_count] != '\0';char_count++) 
        temp[char_count] = s[char_count];
    
    __asm__ __volatile__ (
        "movl $1, %%eax \n\t"
        "movq $1, %%rdi \n\t"
        "syscall \n\t"
        :
        :"S"(temp),"d"(char_count)
        );

    return char_count; // return length
}

//function to read int
int readInt(int *n) 
{
    char bufferarray[100];
    int fl = 0;
    int val = 0;
    int i = 0;
       
    __asm__ __volatile__ (
          "movl $0, %%eax \n\t"
          "movq $1, %%rdi \n\t"
          "syscall \n\t"
          :
          :"S"(bufferarray), "d"(sizeof(bufferarray))
    ) ;
 
  
    if (bufferarray[0] == '-'){
        fl = 1;
        i++;
    }
 
    while(bufferarray[i] != '\n' && bufferarray[i] != ' ' && bufferarray[i] != '\t')
    {
        if (( ((int)bufferarray[i]-'0' > 9) || ((int)bufferarray[i]-'0' < 0) ))
            return ERR;
    
        val *= 10;
        val += (bufferarray[i] - '0');
        i++;
    }
 
    if( fl) val *= -1;
    *n = val;                   
    return OK;                 // Return
}

// Function to print int 

int printInt(int n)
{

    char buff[20],zero='0';
    int i=0,j=0,bytes,k;
    if(n<0)
    {
        n=-n;
        buff[i]='-';
        i++;
    }
    if(n==0){
        buff[i]=zero;
        i++;
        }
    while(1){
        if(n==0)
            break;
        buff[i]= (char)(n%10 + zero);
        n=n/10;
        i++;
    }
    if(buff[0]=='-')j=1;
    k=i-1;
    bytes=i;
    while(j<k){
        char tmp;
        tmp=buff[j];
        buff[j]=buff[k];
        buff[k]=tmp;
        j++;k--;
    }
  __asm__ __volatile__ (
        "movl $1, %%eax \n\t"
        "movq $1, %%rdi \n\t"
        "syscall \n\t"

        :
        :"S"(buff), "d"(bytes)
    );
    return bytes;
}

//function to read float 
int readFlt(float *f) {
	char buff[100];
      float val = 0;
      float dec=1;
    int fl = 0,i = 0 , neg = 0;
    
    __asm__ __volatile__ (
          "movl $0, %%eax \n\t"
          "movq $1, %%rdi \n\t"
          "syscall \n\t"
          :
          :"S"(buff), "d"(sizeof(buff))
    ) ;
 
    // Check if buff is negative
    if (buff[0] == '-'){
        neg = 1;
        i++;
    }

    // Read until newline 
    while(buff[i] != '\n' && buff[i] != ' ' && buff[i] != '\t')
    {
        // If not float
        if (( ((int)buff[i]-'0' > 9) || ((int)buff[i]-'0' < 0) ) && (buff[i] != '.' || fl))
            return ERR;
        
        // Mark the decimal point
        if(buff[i] == '.')
        {
            fl=1;
            i++;
            continue;
        }
        // Convert the array to floating point 
        if(!fl)
        {
            val *= 10;
            val += (int)(buff[i] - '0');
        }
        else
        {
            dec *=10;
            val += (buff[i] - '0')/dec;
        }
        i++;
    }
    
      if(neg)
        val *= -1;
	*f = val;
	return OK; 
}

// Function to print float 

 int printFlt(float f)
{
	char temp1[1000];
	int flag=0,i=0;
   
    if(!f) 
    {
        temp1[i++] ='0';
        temp1[i++] ='.';
        temp1[i++] = '0';
    }
    else
    {
        if(f < 0)     // number is negative
        {
            flag=1;
            f*=-1;
        }

        // position of  decimal point from right
        int dec = 0;
        while((int)f != f)
        {
            f*=10;
            dec++;
        } 
       
        // If no decimal, start with a 0
        if(!dec)
            temp1[i++] = '0',temp1[i++]='.';

        int n = f;
        while(n)
        {
            if(i == dec) temp1[i++] = '.'; // Place the decimal point in the correct position

            temp1[i++] = n%10 + '0'; // Create an array with the digits of the number
            n/=10;
        }
        if(i == dec)
            temp1[i++]='.',temp1[i++]='0';
        if(flag) temp1[i++]='-';
        
        // reverse the array

        for(int j=0,k=i-1;j<k;j++,k--)
        {
            char ar = temp1[j];
            temp1[j] = temp1[k];
            temp1[k] = ar;
        }
    }

	__asm__ __volatile__ (
        "movl $1, %%eax \n\t"
        "movq $1, %%rdi \n\t"
        "syscall \n\t"
        :
        :"S"(temp1),"d"(i)
        );

    return i; // Return  
}