/*
ANKIT LALOTRA
19CS30004
Assignment-2
date:2/09/2021
*/

#include "myl.h"      // header file

int main()
{
       // print of the string
    char *str = "Enter an integer: ";
    printStr(str);
    
    int n;
    if(readInt(&n))        // accept integer
    {
        char *str2 = "You have entered: ";
        printStr(str2);
        printInt(n);          // Print integer
    }
    else 
    {
        char *str2 = "ERROR: Not an integer";
        printStr(str2);
    }
    
    char *str3 = "\nEnter a floating point number: ";
     printStr(str3);
    
    float f=0.211;
    if(readFlt(&f)) // If a valid float is entered
    {
        char *str1 = "You have entered: ";
        printStr(str2);
        printFlt(f);             // Print FLoat
    }

    else 
    {
        char *str2 = "ERROR: Not a floating point number";
        printStr(str2);
    }        

}